using UnityEngine;
using Unity.Mathematics;

public class FlowFieldTestBootstrap : MonoBehaviour
{
    public static FlowFieldSampler Sampler;

    [Header("Flow Field")]
    public FlowField flowField;

    [Header("Grid Settings")]
    [Min(1)] public int width = 32;
    [Min(1)] public int height = 32;
    [Min(0.1f)] public float cellSize = 1f;

    [Header("Target")]
    public Transform target;

    private FlowFieldGrid _grid;

    private void Start()
    {
        CreateFlowField();
    }

#if UNITY_EDITOR
    private void OnValidate()
    {
        width = Mathf.Max(1, width);
        height = Mathf.Max(1, height);
        cellSize = Mathf.Max(0.1f, cellSize);
    }
#endif

    private void CreateFlowField()
    {
        Vector2 gridOrigin = GetGridOrigin();

        _grid = new FlowFieldGrid(
            width,
            height,
            cellSize,
            gridOrigin
        );

        for (int i = 0; i < _grid.CellCount; i++)
            _grid.Cost[i] = 1;

        flowField = new FlowField(_grid);

        if (target != null)
        {
            int2 targetCell = FlowFieldGridUtility.WorldToCell(
                target.position,
                _grid.Origin,
                _grid.CellSize
            );

            flowField.Build(targetCell);
        }

        Sampler = new FlowFieldSampler(_grid);
    }

    private Vector2 GetGridOrigin()
    {
        return (Vector2)transform.position -
               new Vector2(
                   width * cellSize * 0.5f,
                   height * cellSize * 0.5f);
    }

    private void OnDestroy()
    {
        flowField?.Dispose();
    }

    private void OnDrawGizmos()
    {
        float gridWidth = width * cellSize;
        float gridHeight = height * cellSize;

        Vector3 gridOrigin =
            transform.position -
            new Vector3(
                gridWidth * 0.5f,
                0f,
                gridHeight * 0.5f);

        // Grid lines
        Gizmos.color = Color.gray;

        for (int x = 0; x <= width; x++)
        {
            Vector3 start = gridOrigin + new Vector3(x * cellSize, 0f, 0f);
            Vector3 end = gridOrigin + new Vector3(x * cellSize, 0f, gridHeight);

            Gizmos.DrawLine(start, end);
        }

        for (int y = 0; y <= height; y++)
        {
            Vector3 start = gridOrigin + new Vector3(0f, 0f, y * cellSize);
            Vector3 end = gridOrigin + new Vector3(gridWidth, 0f, y * cellSize);

            Gizmos.DrawLine(start, end);
        }

        // Grid boundary
        Gizmos.color = Color.white;

        Gizmos.DrawWireCube(
            transform.position,
            new Vector3(gridWidth, 0.01f, gridHeight));
    }

    private void OnDrawGizmosSelected()
    {
        if (target == null)
            return;

        float gridWidth = width * cellSize;
        float gridHeight = height * cellSize;

        Vector3 gridOrigin =
            transform.position -
            new Vector3(
                gridWidth * 0.5f,
                0f,
                gridHeight * 0.5f);

        int x = Mathf.FloorToInt(
            (target.position.x - gridOrigin.x) / cellSize);

        int y = Mathf.FloorToInt(
            (target.position.z - gridOrigin.z) / cellSize);

        if (x < 0 || x >= width ||
            y < 0 || y >= height)
        {
            Gizmos.color = Color.red;
            Gizmos.DrawSphere(target.position, 0.3f);
            return;
        }

        Vector3 cellCenter =
            gridOrigin +
            new Vector3(
                (x + 0.5f) * cellSize,
                0f,
                (y + 0.5f) * cellSize);

        // Target cell
        Gizmos.color = Color.green;

        Gizmos.DrawCube(
            cellCenter,
            new Vector3(
                cellSize * 0.9f,
                0.05f,
                cellSize * 0.9f));

        // Target position
        Gizmos.color = Color.red;
        Gizmos.DrawSphere(target.position, 0.2f);

        // Connection line
        Gizmos.DrawLine(target.position, cellCenter);
    }
}